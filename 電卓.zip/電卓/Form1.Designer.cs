﻿namespace 電卓
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btnC = new Button();
            btn0 = new Button();
            btnEqual = new Button();
            btnDiv = new Button();
            btnMulti = new Button();
            btnMinus = new Button();
            btnPlus = new Button();
            btnPoint = new Button();
            btnAC = new Button();
            textAns = new TextBox();
            SuspendLayout();
            // 
            // btn7
            // 
            btn7.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn7.Location = new Point(12, 75);
            btn7.Name = "btn7";
            btn7.Size = new Size(75, 74);
            btn7.TabIndex = 0;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btn7_Click;
            // 
            // btn8
            // 
            btn8.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn8.Location = new Point(93, 75);
            btn8.Name = "btn8";
            btn8.Size = new Size(75, 74);
            btn8.TabIndex = 1;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btn8_Click;
            // 
            // btn9
            // 
            btn9.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn9.Location = new Point(174, 75);
            btn9.Name = "btn9";
            btn9.Size = new Size(75, 74);
            btn9.TabIndex = 2;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btn9_Click;
            // 
            // btn4
            // 
            btn4.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn4.Location = new Point(12, 155);
            btn4.Name = "btn4";
            btn4.Size = new Size(75, 74);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn5
            // 
            btn5.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn5.Location = new Point(93, 155);
            btn5.Name = "btn5";
            btn5.Size = new Size(75, 74);
            btn5.TabIndex = 4;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click;
            // 
            // btn6
            // 
            btn6.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn6.Location = new Point(174, 155);
            btn6.Name = "btn6";
            btn6.Size = new Size(75, 74);
            btn6.TabIndex = 5;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += btn6_Click;
            // 
            // btn1
            // 
            btn1.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn1.Location = new Point(12, 235);
            btn1.Name = "btn1";
            btn1.Size = new Size(75, 74);
            btn1.TabIndex = 6;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // btn2
            // 
            btn2.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn2.Location = new Point(93, 235);
            btn2.Name = "btn2";
            btn2.Size = new Size(75, 74);
            btn2.TabIndex = 7;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // btn3
            // 
            btn3.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn3.Location = new Point(174, 235);
            btn3.Name = "btn3";
            btn3.Size = new Size(75, 74);
            btn3.TabIndex = 8;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btnC
            // 
            btnC.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnC.Location = new Point(93, 395);
            btnC.Name = "btnC";
            btnC.Size = new Size(75, 74);
            btnC.TabIndex = 9;
            btnC.Text = "C";
            btnC.UseVisualStyleBackColor = true;
            btnC.Click += btnC_Click;
            // 
            // btn0
            // 
            btn0.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btn0.Location = new Point(12, 315);
            btn0.Name = "btn0";
            btn0.Size = new Size(156, 74);
            btn0.TabIndex = 10;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += btn0_Click;
            // 
            // btnEqual
            // 
            btnEqual.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnEqual.Location = new Point(254, 395);
            btnEqual.Name = "btnEqual";
            btnEqual.Size = new Size(75, 74);
            btnEqual.TabIndex = 11;
            btnEqual.Text = "＝";
            btnEqual.UseVisualStyleBackColor = true;
            btnEqual.Click += btnEqual_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnDiv.Location = new Point(255, 75);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(75, 74);
            btnDiv.TabIndex = 12;
            btnDiv.Text = "÷";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // btnMulti
            // 
            btnMulti.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnMulti.Location = new Point(255, 155);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(75, 74);
            btnMulti.TabIndex = 13;
            btnMulti.Text = "×";
            btnMulti.UseVisualStyleBackColor = true;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnMinus
            // 
            btnMinus.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnMinus.Location = new Point(255, 235);
            btnMinus.Name = "btnMinus";
            btnMinus.Size = new Size(75, 74);
            btnMinus.TabIndex = 14;
            btnMinus.Text = "-";
            btnMinus.UseVisualStyleBackColor = true;
            btnMinus.Click += btnMinus_Click;
            // 
            // btnPlus
            // 
            btnPlus.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnPlus.Location = new Point(255, 315);
            btnPlus.Name = "btnPlus";
            btnPlus.Size = new Size(75, 74);
            btnPlus.TabIndex = 15;
            btnPlus.Text = "+";
            btnPlus.UseVisualStyleBackColor = true;
            btnPlus.Click += btnPlus_Click;
            // 
            // btnPoint
            // 
            btnPoint.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnPoint.Location = new Point(174, 315);
            btnPoint.Name = "btnPoint";
            btnPoint.Size = new Size(75, 74);
            btnPoint.TabIndex = 16;
            btnPoint.Text = ".";
            btnPoint.UseVisualStyleBackColor = true;
            btnPoint.Click += btnPoint_Click;
            // 
            // btnAC
            // 
            btnAC.Font = new Font("Yu Gothic UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 128);
            btnAC.Location = new Point(12, 395);
            btnAC.Name = "btnAC";
            btnAC.Size = new Size(75, 74);
            btnAC.TabIndex = 17;
            btnAC.Text = "AC";
            btnAC.UseVisualStyleBackColor = true;
            btnAC.Click += btnAC_Click;
            // 
            // textAns
            // 
            textAns.Font = new Font("Yu Gothic UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 128);
            textAns.Location = new Point(12, 15);
            textAns.MaxLength = 16;
            textAns.Name = "textAns";
            textAns.ReadOnly = true;
            textAns.Size = new Size(317, 50);
            textAns.TabIndex = 18;
            textAns.TextAlign = HorizontalAlignment.Right;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(341, 475);
            Controls.Add(textAns);
            Controls.Add(btnAC);
            Controls.Add(btnPoint);
            Controls.Add(btnPlus);
            Controls.Add(btnMinus);
            Controls.Add(btnMulti);
            Controls.Add(btnDiv);
            Controls.Add(btnEqual);
            Controls.Add(btn0);
            Controls.Add(btnC);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Name = "Form1";
            Text = "電卓ツール";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btnC;
        private Button btn0;
        private Button btnEqual;
        private Button btnDiv;
        private Button btnMulti;
        private Button btnMinus;
        private Button btnPlus;
        private Button btnPoint;
        private Button btnAC;
        private TextBox textAns;
    }
}
