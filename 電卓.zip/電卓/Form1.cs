namespace 電卓
{
    public partial class Form1 : Form
    {

        //変数定義
        String strAns = "0";
        double num1 = 0;
        double num2 = 0;
        int ennzannsi = 0;//四則演算を識別する(1.足し算 2.引き算 3.掛け算 4.割り算)
        bool pointFlg = false;
        int keta = 0;//15桁までカウント

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textAns.Text = strAns;

            numberUnlock();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("1");
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("2");
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("3");
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("4");
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("5");
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("6");
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("7");
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("8");
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (keta < 15)
            {
                ConnectNum("9");
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if ((strAns != "0" || num1 != 0) && keta < 14)
            {
                if (keta < 15)
                {
                    ConnectNum("0");

                    if (num1 != 0 && keta == 1)
                    {
                        keta = keta - 1;
                    }
                }
            }
        }

        private void btnPoint_Click(object sender, EventArgs e)
        {
            if (pointFlg == false)
            {
                if (keta < 15)
                {
                    ConnectNum(".");
                }
            }
            pointFlg = true;
        }

        
        //テキストボックス消す
        private void btnC_Click(object sender, EventArgs e)
        {
            strAns = "0";
            textAns.Text = "0";
            pointFlg = false;
            keta = 0;
        }


        //テキストボックス、計算含めすべて消す
        private void btnAC_Click(object sender, EventArgs e)
        {
            strAns = "0";
            textAns.Text = "0";
            num1 = 0;
            num2 = 0;
            ennzannsi = 0;
            pointFlg = false;
            keta = 0;
            numberUnlock();
            
        }
        //足し算
        private void btnPlus_Click(object sender, EventArgs e)
        {
            ennzannsi = 1;
            num1 = double.Parse(strAns);
            strAns = "0";
            pointFlg = false;
            keta = 0;
            numberUnlock();
            ennzannsiLock();
        }

        //引き算
        private void btnMinus_Click(object sender, EventArgs e)
        {
            ennzannsi = 2;
            num1 = double.Parse(strAns);
            strAns = "0";
            pointFlg = false;
            keta = 0;
            numberUnlock();
            ennzannsiLock();
        }

        //かけ算
        private void btnMulti_Click(object sender, EventArgs e)
        {
            ennzannsi = 3;
            num1 = double.Parse(strAns);
            strAns = "0";
            pointFlg = false;
            keta = 0;
            numberUnlock();
            ennzannsiLock();
        }

        //割り算
        private void btnDiv_Click(object sender, EventArgs e)
        {
            ennzannsi = 4;
            num1 = double.Parse(strAns);
            strAns = "0";
            pointFlg = false;
            keta = 0;
            numberUnlock();
            ennzannsiLock();
        }

        //イコールが押された時の処理
        private void btnEqual_Click(object sender, EventArgs e)
        {
            double ans = 0;

            //どの数字も押されずにイコールが押された場合同じ数字同士で計算するようにする
            if (strAns != "0" || keta ==0)
            {
                num2 = double.Parse(strAns);
            }
            else
            {
                num2 = num1;
            }

            if(ennzannsi==4 && num2 == 0)//0では割れないのでエラー文を出す
            {
                strAns = "0で割ることはできません";
                textAns.Text = strAns;
                numberLock();
                ennzannsiLock();
                btnEqual.Enabled = false;
                btnC.Enabled = false;
            }
            else
            {

            
                switch (ennzannsi)
                {
                    case 1: ans = num1 + num2; break;
                    case 2: ans = num1 - num2; break;
                    case 3: ans = num1 * num2; break;
                    case 4: ans = num1 / num2; break;
                }

                //計算結果が小数点以上が15桁を超える場合エラー文を出す
                if (ans < 1000000000000000 && ans > -1000000000000000)
                {
                    strAns = ans.ToString();
                    numberLock();
                    ennzannsiUnlock();
                }
                else
                {
                    strAns = "文字数エラー";
                    numberLock();
                    ennzannsiLock();
                    btnEqual.Enabled = false;
                    btnC.Enabled = false;
                }

                textAns.Text = strAns;

                strAns=textAns.Text;

                pointFlg = false;

                keta = 0;

            }

        }

        //電卓のテキストボックスに数字,小数点を入れる関数
        private void ConnectNum(string strNum)
        {
            if (strAns != "0" || strNum == ".")
            {
                strAns = strAns + strNum;
            }
            else
            {
                strAns = strNum;
            }

            textAns.Text = strAns;
            keta = keta + 1;
        }

        //数字、小数点ボタンをロックする関数
        private void numberLock()
        {
            btn0.Enabled = false;
            btn1.Enabled = false;
            btn2.Enabled = false;
            btn3.Enabled = false;
            btn4.Enabled = false;
            btn5.Enabled = false;
            btn6.Enabled = false;
            btn7.Enabled = false;
            btn8.Enabled = false;
            btn9.Enabled = false;
            btnPoint.Enabled = false;
        }

        //数字、小数点ボタンを開放する関数
        private void numberUnlock()
        {
            btn0.Enabled = true;
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
            btnPoint.Enabled = true;
            btnPlus.Enabled = true;
            btnMinus.Enabled = true;
            btnMulti.Enabled = true;
            btnDiv.Enabled = true;
            btnEqual.Enabled = true;
            btnC.Enabled = true;
        }

        //演算子ボタンのロック
        private void ennzannsiLock()
        {
            btnPlus.Enabled = false;
            btnMinus.Enabled = false;
            btnMulti.Enabled = false;
            btnDiv.Enabled = false;
        }

        //演算子ボタンの開放
        private void ennzannsiUnlock()
        {
            btnPlus.Enabled = true;
            btnMinus.Enabled = true;
            btnMulti.Enabled = true;
            btnDiv.Enabled = true;
        }
    }
}
